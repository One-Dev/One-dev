<?php
require_once 'lib/ConectorS3.php';
$file='script.txt';
ConectorS3::descargaS3($file);




